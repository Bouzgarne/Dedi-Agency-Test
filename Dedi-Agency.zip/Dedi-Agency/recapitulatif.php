<?php 
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<title>Test Intervention</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
</head>
<body>

	<div>
      <nav class="navbar navbar-dark bg-dark justify-content-between">
        <div class="container">
          <h1 class="navbar-brand">Test Dedi Agency</h1>
          <a href="index.php"><i class="fas fa-home text-white"></i></a>
        </div>
      </nav>
    </div><br>

    <div class="container">
        <div class="row center">
        	<div class="col-md-12">

        		<br>
                <h1 class="text-center">Récapitulatif</h1><hr><br>            
                
		    	<form role="form" autocomplete="on" method="POST" action="confirmation_demande.php" >
				  <div class="form-row">
				    <div class="form-group col-md-6">
				      <label >Votre nom : <b><?php echo $_SESSION['name']; ?></b>
				    </div>
				    <div class="form-group col-md-6">
				      <label >Bureau n° : <b><?php echo $_SESSION['bureau']; ?></b></label>
				    </div>
				  </div>

				  <fieldset class="form-group">
				    <div class="row">
				      	<div class="col-auto my-1">
					        <label class="mr-sm-2" >Votre problème concerne : <b><?php echo $_SESSION['probleme']; ?></b></label>
					    </div>
				    </div>
				  </fieldset>

				  <div class="form-group">
				    <label >Remarque : <b><?php echo $_SESSION['remarque']; ?></b></label>
				  </div>

				  <div class="form-group">
				    <label >Description du problème : <b><?php echo $_SESSION['description']; ?></b></label>
				  </div>
				  
				  
				  <div class="form-group row">
				    <div class="col-sm-10">
				      <button type="submit" name="submit" class="btn btn-primary">Je confirme ma demande d'intervention</button>
				    </div>
				  </div>
				</form>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>