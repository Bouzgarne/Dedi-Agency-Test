-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 20 déc. 2018 à 17:17
-- Version du serveur :  5.7.19
-- Version de PHP :  7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `intervention`
--

-- --------------------------------------------------------

--
-- Structure de la table `intervention`
--

DROP TABLE IF EXISTS `intervention`;
CREATE TABLE IF NOT EXISTS `intervention` (
  `id_interv` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) NOT NULL,
  `bureau` varchar(5) NOT NULL,
  `probleme` varchar(40) NOT NULL,
  `remarque` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `dateAjout` date NOT NULL,
  `suivi` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_interv`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `intervention`
--

INSERT INTO `intervention` (`id_interv`, `username`, `bureau`, `probleme`, `remarque`, `description`, `dateAjout`, `suivi`) VALUES
(19, 'Jimmy', '9BO4', 'Tous les ordinateurs', 'Plus de réseaux', 'Pas de réseaux au 2 ième étage', '2018-12-20', 'En cours'),
(18, 'Karim', 'C980', 'Une imprimante', 'Pc du bureau', 'Plus d\'ancre', '2018-12-20', 'En cours'),
(20, 'Henry', 'C580', 'Autre', 'Pc bureau ', '1 écran sur deux qui fonctionne', '2018-12-20', 'Réparé'),
(21, 'Henry', 'C580', 'Autre', 'Pc bureau ', '1 écran sur deux qui fonctionne', '2018-12-20', 'Réparé'),
(22, 'Henry', 'C580', 'Autre', 'Pc bureau ', '1 écran sur deux qui fonctionne', '2018-12-20', 'En cours'),
(23, 'Henry', 'C580', 'Autre', 'Pc bureau ', '1 écran sur deux qui fonctionne', '2018-12-20', 'En cours'),
(24, 'James', 'B8B9', 'Un ou plusieurs ordinateur(s)', 'Bureau salle 3', 'Plus d\'accès internet', '2018-12-20', 'Réparé'),
(25, 'James', 'B8B9', 'Un ou plusieurs ordinateur(s)', 'Bureau salle 3', 'Plus d\'accès internet', '2018-12-20', 'Réparé'),
(26, 'James', 'B8B9', 'Un ou plusieurs ordinateur(s)', 'Bureau salle 3', 'Plus d\'accès internet', '2018-12-20', 'Réparé'),
(27, 'James', 'B8B9', 'Un ou plusieurs ordinateur(s)', 'Bureau salle 3', 'Plus d\'accès internet', '2018-12-20', 'Réparé');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
