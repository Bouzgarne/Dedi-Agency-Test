<?php 
  session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <title>Test Intervention</title>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

</head>
<body>

  <div>
      <nav class="navbar navbar-dark bg-dark justify-content-between">
        <div class="container">
          <h1 class="navbar-brand">Test Dedi Agency</h1>          
          <a href="index.php"><i class="fas fa-home text-white"></i></a>
        </div>
      </nav>
    </div><br>

    <div class="container">
        <div class="row center">
          <div class="col-md-12">

            <br>
            <h1 class="text-center">Récapitulatif</h1><hr><br>            
                


<?php
require "connexion_db.php";


$name = $_SESSION["name"] ;
$bureau = $_SESSION["bureau"] ;
$probleme = $_SESSION["probleme"];
$remarque = $_SESSION["remarque"]; 
$description = $_SESSION["description"];


// Recherche des données saisies dans le formulaires

if(isset($_POST['submit']))
{
  date_default_timezone_set('Europe/Paris');   
  $query = $bdd->prepare('INSERT INTO intervention (username,bureau, probleme ,remarque,description, dateAjout) VALUES(:username, :bureau, :probleme, :remarque, :description ,:dateAjout)');
  $query->execute([
  ':username' => $name,
  ':bureau' => $bureau,
  ':probleme' => $probleme,
  ':remarque' => $remarque,
  ':description' => $description,
  ':dateAjout' => date('Y-m-d H:i:s')  ,]) 
  or die(print_r($query->errorInfo(), TRUE));

 
  echo '<h2>Votre demande a bien été enregistré</h2><br>
        <a href="index.php"><button type="button" class="btn btn-primary">Retour à l\'accueil</button></a> ';
} 

else {
  echo "Erreur dans la demande" ;
}


?>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>
