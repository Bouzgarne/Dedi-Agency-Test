<?php
  session_start();


// Connexion à la base de données


require "connexion_db.php";


// Declaration des variables passé en POST

$name = htmlspecialchars($_POST['name']);
$bureau = htmlspecialchars($_POST['bureau']);
$probleme = htmlspecialchars($_POST['probleme']);
$remarque = htmlspecialchars($_POST['remarque']);
$description = htmlspecialchars($_POST['description']);

$_SESSION["name"] = $name;
$_SESSION["bureau"] = $bureau;
$_SESSION["probleme"] = $probleme;
$_SESSION["remarque"] = $remarque; 
$_SESSION["description"] = $description;


// Recherche des données saisies dans le formulaires

if(isset($_POST['submit']))
{
  echo "<script type='text/javascript'>document.location.replace('recapitulatif.php');</script>";
} 

else {
  echo "Erreur dans le formulaire" ;
}
    


  



?>