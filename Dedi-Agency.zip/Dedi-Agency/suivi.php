<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<title>Test Intervention</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
</head>
<body>

	<div>
      <nav class="navbar navbar-dark bg-dark justify-content-between">
        <div class="container">
          <h1 class="navbar-brand">Test Dedi Agency</h1>
          <a href="index.php"><i class="fas fa-home text-white"></i></a>
        </div>
      </nav>
    </div><br>		

    <div class="container">
        <div class="row center">
        	<div class="col-md-12">

        		<br>
                <h1 class="text-center">Suivie des demandes d'interventions informatiques</h1><hr><br>      

                <?php
			// Connexion à la base de données
			require "connexion_db.php";

			$sql = 'SELECT * FROM intervention' ;
	        			
		    $reponse = $bdd->prepare($sql);
		    $reponse->execute(array());

		?>   
		    	<table class="table">
				  <thead class="bg-dark text-white">
				    <tr>
				      <th scope="col">Num</th>
				      <th scope="col">Salle</th>
				      <th scope="col">Description</th>
				      <th scope="col">Remarques</th>
				      <th scope="col">Demandé le</th>
				      <th scope="col">Suivi</th>
				      <th scope="col"></th> 
				    </tr>
				  </thead>
				  <!-- On parcourt la bdd pour afficher les résultats ligne par ligne -->
			  	<?php 

			  	while($data = $reponse->fetch())
		        {
		        ?>
				  <tbody>
				    <tr>
				      <th><?php echo "<span>".htmlspecialchars($data['id_interv'])."</span>" ;?></th>
				      <td><?php echo "<span>".htmlspecialchars($data['bureau'])."</span>" ;?></td>
				      <td><?php echo "<span>".htmlspecialchars($data['description'])."</span>" ;?></td>
				      <td><?php echo "<span>".htmlspecialchars($data['remarque'])."</span>" ;?></td>
				      <td><?php echo "<span>".htmlspecialchars($data['dateAjout'])."</span>" ;?></td>
				      <td><?php echo "<span>".htmlspecialchars($data['suivi'])."</span>" ;?></td>
				      <td><a href="#"><i class="far fa-eye"></i></a></td>
				    </tr>
				  </tbody>
				  <?php
	          	}
	          
	          	$reponse->Closecursor();
	          
	          	?>   
				</table>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>